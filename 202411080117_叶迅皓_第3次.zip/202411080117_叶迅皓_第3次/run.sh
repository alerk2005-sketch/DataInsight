#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
lab_build_dir="$(mktemp -d "${TMPDIR:-/tmp}/java-lab03.XXXXXX")"
trap 'rm -rf -- "$lab_build_dir"' EXIT
javac -encoding UTF-8 --release 17 -d "$lab_build_dir" DataRecord.java Dataset.java DataInsight.java
java -cp "$lab_build_dir" DataInsight
