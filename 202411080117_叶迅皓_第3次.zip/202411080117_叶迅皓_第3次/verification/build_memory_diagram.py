"""生成教学示意内存图，SVG 和 PNG 共用相同的图元与文字。"""
from pathlib import Path
from html import escape
from math import atan2, cos, sin
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figure"
OUT.mkdir(exist_ok=True)
W, H = 1400, 940
image = Image.new("RGB", (W, H), "#ffffff")
draw = ImageDraw.Draw(image)
font_path = "/System/Library/Fonts/STHeiti Medium.ttc"
svg = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
       '<rect width="100%" height="100%" fill="white"/>',
       '<defs><marker id="arrow" markerWidth="10" markerHeight="10" refX="8" refY="5" orient="auto"><path d="M0,0 L10,5 L0,10 Z" fill="#2563a6"/></marker></defs>']

def rect(x, y, w, h, fill, stroke="#cbd5e1", radius=12):
    draw.rounded_rectangle((x, y, x+w, y+h), radius, fill=fill, outline=stroke, width=2)
    svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{radius}" fill="{fill}" stroke="{stroke}" stroke-width="2"/>')

def text(x, y, content, size=26, color="#172b44"):
    font = ImageFont.truetype(font_path, size)
    draw.text((x, y), content, font=font, fill=color)
    svg.append(f'<text x="{x}" y="{y+size}" fill="{color}" font-family="STHeiti, PingFang SC, sans-serif" font-size="{size}">{escape(content)}</text>')

def arrow(x1, y1, x2, y2):
    draw.line((x1, y1, x2, y2), fill="#2563a6", width=4)
    angle = atan2(y2-y1, x2-x1)
    points = [(x2,y2), (x2-16*cos(angle-0.45), y2-16*sin(angle-0.45)),
              (x2-16*cos(angle+0.45), y2-16*sin(angle+0.45))]
    draw.polygon(points, fill="#2563a6")
    svg.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#2563a6" stroke-width="4" marker-end="url(#arrow)"/>')

text(60, 40, "思考题 1：两个引用，共享一个对象", 42)
text(60, 105, "简化内存图：b.setScore(90) 执行后", 27, "#52647a")
rect(60, 160, 1280, 84, "#f4f7fb")
text(85, 182, 'DataRecord a = new DataRecord(1L, "张三", 95);   DataRecord b = a;', 25)

rect(60, 280, 380, 300, "#eff6ff", "#93b8e5")
text(85, 302, "main 方法的栈帧（示意）", 27)
rect(90, 365, 310, 64, "#ffffff", "#93b8e5")
text(110, 380, "a：指向同一对象的引用", 24)
rect(90, 475, 310, 64, "#ffffff", "#93b8e5")
text(110, 490, "b：复制 a 的引用值", 24)

rect(650, 280, 690, 300, "#f0f9f5", "#9cccb6")
text(675, 302, "堆（Heap）", 27)
rect(710, 355, 320, 175, "#ffffff", "#9cccb6")
text(735, 370, "DataRecord 对象", 26)
text(735, 415, "id = 1", 26)
text(735, 450, "name = 字符串引用", 26)
text(735, 485, "score = 90（原为 95）", 26, "#146444")
rect(1100, 420, 190, 80, "#ffffff", "#9cccb6")
text(1120, 434, 'String 对象', 24)
text(1140, 467, '"张三"', 24)
arrow(400, 396, 710, 397)
arrow(400, 506, 710, 480)
arrow(1030, 466, 1100, 466)
text(465, 424, "a == b 为 true", 22, "#2563a6")

rect(60, 625, 1280, 104, "#f8f5ec", "#d8c78f")
text(85, 644, "类级别的共享状态（概念示意）", 27)
text(85, 686, "DataRecord.count / PASS_LINE 与 Dataset.count 属于各自的类，不是每个实例各存一份。", 24)
text(60, 778, "通过 b.setScore(90) 修改对象后，a.getScore() 和 b.getScore() 都返回 90。", 27)
text(60, 827, "如果只重新给 b 赋值（例如 b = null），a 仍指向原对象，a 不受影响。", 26)
text(60, 887, "说明：图中不展示 JVM 的实现细节；箭头表示引用关系，不表示真实内存地址。", 22, "#52647a")

svg.append("</svg>")
(OUT / "内存图.svg").write_text("\n".join(svg), encoding="utf-8")
image.save(OUT / "内存图.png")
print("已生成 figure/内存图.svg 与 figure/内存图.png")
