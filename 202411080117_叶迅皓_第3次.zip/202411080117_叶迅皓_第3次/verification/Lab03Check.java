/** 额外验证：运行于独立 JVM，不影响 DataInsight 演示中的静态计数。 */
public class Lab03Check {
    private static int checks = 0;

    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    private static void close(double actual, double expected, String message) {
        check(Math.abs(actual - expected) < 1e-9, message);
    }

    private static void throwsType(Class<? extends Exception> type, Runnable action) {
        try {
            action.run();
        } catch (Exception ex) {
            check(type.isInstance(ex), "异常类型错误: " + ex);
            return;
        }
        check(false, "预期异常未抛出: " + type.getSimpleName());
    }

    public static void main(String[] args) {
        int recordStart = DataRecord.getCount();
        DataRecord record = new DataRecord(1L, "测试学生");
        check(record.getScore() == 0, "双参构造默认分数");
        check(DataRecord.getCount() == recordStart + 1, "构造器委托只能计数一次");
        check(record.getId() == 1L && "测试学生".equals(record.getName()), "构造赋值");
        record.setId(2L);
        record.setName("修改后的姓名");
        check(record.getId() == 2L && "修改后的姓名".equals(record.getName()), "getter/setter");

        int[] scores = {0, 59, 60, 79, 80, 89, 90, 100};
        String[] grades = {"D", "D", "C", "C", "B", "B", "A", "A"};
        for (int i = 0; i < scores.length; i++) {
            record.setScore(scores[i]);
            check(record.getScore() == scores[i], "合法分数边界");
            check(record.grade().equals(grades[i]), "等级边界: " + scores[i]);
            check(record.isPass() == (scores[i] >= 60), "及格边界: " + scores[i]);
        }
        record.setScore(-1);
        check(record.getScore() == 100, "负分应保留原值");
        record.setScore(101);
        check(record.getScore() == 100, "超范围分数应保留原值");
        DataRecord invalid = new DataRecord(3L, "非法分数", 120);
        check(invalid.getScore() == 0, "非法构造分数保留默认值 0");
        check(DataRecord.getCount() == recordStart + 2, "两个对象累计计数");

        DataRecord other = new DataRecord(4L, "另一位学生", 59);
        DataRecord[] source = {record, other};
        int datasetStart = Dataset.getCount();
        Dataset dataset = new Dataset(source);
        check(dataset.size() == 2, "数据集长度");
        close(dataset.average(), 79.5, "平均分不能整数截断");
        check(dataset.max() == 100 && dataset.min() == 59, "最高分与最低分");
        check(dataset.passCount() == 1, "及格人数");
        close(dataset.passRate(), 0.5, "及格率单位为比例");
        source[0] = invalid;
        check(dataset.max() == 100, "原数组替换元素不能改变聚合组成");
        DataRecord alias = record;
        alias.setScore(60);
        check(record.getScore() == 60, "两个引用指向同一个对象");
        close(dataset.average(), 59.5, "对象修改应反映到聚合统计");

        Dataset empty = new Dataset(new DataRecord[0]);
        check(empty.size() == 0 && empty.passCount() == 0, "空集计数");
        close(empty.average(), 0.0, "空集平均分约定");
        close(empty.passRate(), 0.0, "空集及格率约定");
        throwsType(IllegalStateException.class, empty::max);
        throwsType(IllegalStateException.class, empty::min);
        throwsType(IllegalArgumentException.class, () -> new Dataset(null));
        throwsType(IllegalArgumentException.class, () -> new Dataset(new DataRecord[]{null}));
        check(Dataset.getCount() == datasetStart + 2, "失败构造不能增加数据集计数");
        Dataset singleton = new Dataset(new DataRecord[]{other});
        close(singleton.average(), 59.0, "单条记录平均值");
        check(singleton.max() == 59 && singleton.min() == 59, "单条记录极值");
        close(singleton.passRate(), 0.0, "全部不及格");
        other.setScore(100);
        close(singleton.passRate(), 1.0, "全部及格");
        System.out.println("验证通过: " + checks + " 项检查全部通过。");
    }
}
