#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")/.."
lab_verify_dir="$(mktemp -d "${TMPDIR:-/tmp}/java-lab03-check.XXXXXX")"
trap 'rm -rf -- "$lab_verify_dir"' EXIT
javac -encoding UTF-8 --release 17 -Xlint:all -d "$lab_verify_dir" DataRecord.java Dataset.java DataInsight.java verification/Lab03Check.java
java -cp "$lab_verify_dir" Lab03Check
