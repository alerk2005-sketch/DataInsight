import java.util.Locale;

/** 实验三主程序：创建记录、验证封装与引用关系、打印统计报告。 */
public class DataInsight {
    public static void main(String[] args) {
        System.out.println("实验三：类与对象建模（JDK 17）");
        System.out.println("--- 构造方法与分数校验 ---");
        DataRecord[] records = {
            new DataRecord(1L, "张三", 95),
            new DataRecord(2L, "李四", 85),
            new DataRecord(3L, "王五", 70),
            new DataRecord(4L, "赵六", 55),
            new DataRecord(5L, "孙七", 120), // 非法分数被拒绝，保留初始值 0。
            new DataRecord(6L, "周八")       // 调用双参构造方法，默认分数 0。
        };
        System.out.println("双参构造默认分数: " + records[5].getScore());
        records[5].setScore(60);
        System.out.println("设置合法分数后: " + records[5].getScore());
        records[0].setScore(-5);
        System.out.println("拒绝非法修改后，原分数保留: " + records[0].getScore());

        System.out.println("--- 引用共享验证 ---");
        DataRecord a = records[0];
        DataRecord b = a;
        System.out.println("a == b: " + (a == b));
        b.setScore(90);
        System.out.println("b.setScore(90) 后，a.score=" + a.getScore()
                + "，b.score=" + b.getScore());

        Dataset dataset = new Dataset(records);
        System.out.println("--- 学生成绩 ---");
        for (DataRecord record : records) {
            record.printInfo();
        }

        System.out.println("--- 数据集统计 ---");
        System.out.println("记录数: " + dataset.size());
        System.out.printf(Locale.ROOT, "平均分: %.2f%n", dataset.average());
        System.out.println("最高分: " + dataset.max());
        System.out.println("最低分: " + dataset.min());
        System.out.println("及格人数: " + dataset.passCount());
        System.out.printf(Locale.ROOT, "及格率: %.2f%%%n", dataset.passRate() * 100);
        System.out.println("累计创建 DataRecord: " + DataRecord.getCount());
        System.out.println("累计创建 Dataset: " + Dataset.getCount());
    }
}
