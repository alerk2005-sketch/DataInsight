/** 一条学生成绩记录：封装字段、校验分数，并统计创建次数。 */
public class DataRecord {
    private long id;
    private String name;
    private int score;

    private static int count = 0;
    public static final int PASS_LINE = 60;

    public DataRecord(long id, String name, int score) {
        this.id = id;
        this.name = name;
        setScore(score);
        count++;
    }

    public DataRecord(long id, String name) {
        this(id, name, 0);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getScore() {
        return score;
    }

    /** 非法分数只打印警告，保留对象原有分数。 */
    public void setScore(int score) {
        if (score >= 0 && score <= 100) {
            this.score = score;
        } else {
            System.out.println("非法分数忽略: " + score);
        }
    }

    public boolean isPass() {
        return score >= PASS_LINE;
    }

    /** A：90~100，B：80~89，C：60~79，D：0~59。 */
    public String grade() {
        if (score >= 90) {
            return "A";
        } else if (score >= 80) {
            return "B";
        } else if (score >= PASS_LINE) {
            return "C";
        } else {
            return "D";
        }
    }

    public void printInfo() {
        System.out.printf("%d %s : %d 分，等级 %s，%s%n",
                id, name, score, grade(), isPass() ? "及格" : "不及格");
    }

    public static int getCount() {
        return count;
    }
}
