/** 聚合成绩记录，通过实例方法计算统计值。 */
public class Dataset {
    private final DataRecord[] records;
    private static int count = 0;

    public Dataset(DataRecord[] records) {
        if (records == null) {
            throw new IllegalArgumentException("记录数组不能为 null");
        }
        for (DataRecord record : records) {
            if (record == null) {
                throw new IllegalArgumentException("记录数组不能包含 null 元素");
            }
        }
        // 复制数组，避免调用者替换数组元素后改变本数据集的组成。
        // 数组中的 DataRecord 引用仍指向原对象，记录的成绩修改会反映到统计中。
        this.records = records.clone();
        count++;
    }

    public int size() {
        return records.length;
    }

    /** 空数据集的平均分约定为 0.0。 */
    public double average() {
        if (records.length == 0) {
            return 0.0;
        }
        long total = 0;
        for (DataRecord record : records) {
            total += record.getScore();
        }
        return (double) total / records.length;
    }

    public int max() {
        checkNotEmpty();
        int highest = records[0].getScore();
        for (DataRecord record : records) {
            if (record.getScore() > highest) {
                highest = record.getScore();
            }
        }
        return highest;
    }

    public int min() {
        checkNotEmpty();
        int lowest = records[0].getScore();
        for (DataRecord record : records) {
            if (record.getScore() < lowest) {
                lowest = record.getScore();
            }
        }
        return lowest;
    }

    public int passCount() {
        int passed = 0;
        for (DataRecord record : records) {
            if (record.isPass()) {
                passed++;
            }
        }
        return passed;
    }

    /** 返回 0.0~1.0 的比例；输出百分数时再乘 100。 */
    public double passRate() {
        return records.length == 0 ? 0.0 : (double) passCount() / records.length;
    }

    private void checkNotEmpty() {
        if (records.length == 0) {
            throw new IllegalStateException("空数据集没有最高分和最低分");
        }
    }

    public static int getCount() {
        return count;
    }
}
