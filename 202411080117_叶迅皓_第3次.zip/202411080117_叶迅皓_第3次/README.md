# Java 应用程序开发实验三报告

- 姓名：叶迅皓
- 学号：202411080117
- 实验：类与对象建模
- 主文件：main.tex
- 原始模板：ZAFU_Java课程_LaTex_模板.zip
- 建议编译引擎：XeLaTeX（模板使用 fontspec 字体命令）

## 模板保留与填充范围

本项目直接从原始模板压缩包建立。ZAFUReport.cls、ZAFUReport.cfg、refs.bib、LICENSE 和 figure/zafu_logo.png 与原压缩包逐字节一致。没有加入字体覆盖、宏包或版式设置。

main.tex 填写 cproject、cname、cnum、ctime 四个封面字段，并按后续要求移除末尾参考文献输出块；其他内容、命令、顺序、注释和空白保持原样。chapter/content.tex 是模板指定的正文填充区，填入实验一至五部分、三份完整 Java 源码、实际运行截图、统计结果、内存图和思考题答案。

模板中的 refs.bib 示例条目属于原模板，保持原样；该条目与本实验无关，正文没有引用它，报告不输出参考文献章节。实验来源在正文以课程指导网页链接标明。

模板类文件引用的是 ZAFUreport.cfg，原文件名为 ZAFUReport.cfg。为兼容区分大小写的平台，提交 ZIP 额外包含一份名称为 ZAFUreport.cfg、内容与原文件完全相同的副本。原类文件和原配置文件没有修改。macOS 解压时，这两个名字可能合并为一个文件，其内容相同，不影响使用。

## 编译说明与当前验证情况

在支持多文件项目的 LaTeX 平台中导入整个 ZIP，以 main.tex 为主文件，选择 XeLaTeX。必须使用整个工程，不能只上传 main.tex。正文中的 lstinputlisting 会读取根目录的三份 Java 源码，图片从 figure/ 中读取。

模板要求 Times New Roman，并由 ctex 按编译环境选择中文字体；应在具有相应字体和宏包的环境中编译，不应为适配预览而改写模板。

当前已尝试内置 LaTeX 编译检查，但未取得返回的编译诊断。内置检查面向单文件，而本模板依赖自定义类、配置、正文、源码及图片。当前交付为完整且可编辑的 LaTeX 工程，未附已验证编译成功的 PDF；Java 程序运行与 52 项检查已通过。模板保留校验结果见“模板保留校验.txt”。

## 提交材料

- main.tex、chapter/content.tex 与原模板资源：LaTeX 报告工程。
- DataRecord.java、Dataset.java、DataInsight.java：本次完整源码。
- figure/运行截图.jpg：IntelliJ IDEA 中真实运行的原始截图。
- figure/内存图.png、figure/内存图.svg：内存图与可编辑矢量版。
- 运行结果.txt：命令行实际输出。
- 思考题答案.md、实验报告.md：相同实验内容的便于阅读版本。
- verification/：52 项检查、结果及内存图生成源。

运行 Java 主程序：bash run.sh。
补充验证：bash verification/verify.sh。

主程序最终成绩为 90、85、70、55、0、60，平均分 60.00，最高分 90，最低分 0，及格人数 4，及格率 66.67%。累计创建记录 6 个、数据集 1 个。

## GitHub 仓库地址

https://github.com/alerk2005-sketch/DataInsight

正文已加入上述仓库地址。
